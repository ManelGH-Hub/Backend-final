package com.PFE.GStagiaire.Repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.PFE.GStagiaire.Entity.RoleType;
import com.PFE.GStagiaire.Entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	User findByLogin(String login);

	  List<User> findByRole(RoleType role);
	

}

