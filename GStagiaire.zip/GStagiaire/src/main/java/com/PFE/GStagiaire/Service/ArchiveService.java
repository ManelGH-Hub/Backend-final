package com.PFE.GStagiaire.Service;

import com.PFE.GStagiaire.Entity.Archive;
import com.PFE.GStagiaire.Entity.StageSubject;
import com.PFE.GStagiaire.Repository.ArchiveRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ArchiveService {
    @Autowired
    private ArchiveRepository archiveRepository;

    public void archiveSubject(StageSubject subject) {
        Archive archive = new Archive();
        archive.setTitle(subject.getTitle());
        archive.setDescription(subject.getDescription());
        archive.setInternName(subject.getInternName());
        archive.setTeamName(subject.getTeamName());
        archive.setSupervisor(subject.getSupervisor());
        archive.setDuration(subject.getDuration());
        archive.setStatus(subject.getStatus());

        archiveRepository.save(archive);
    }
    public long countArchivedSubjects() {
        return archiveRepository.count();
    }
}
