package com.PFE.GStagiaire.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PFE.GStagiaire.Entity.RoleType;
import com.PFE.GStagiaire.Entity.User;
import com.PFE.GStagiaire.Repository.UserRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ImplementationUser {
    @Autowired
    private UserRepository userRepository;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public User updateUser(Long userId, User userDetails) {
        User user = userRepository.findById(userId).orElse(null);
        if (user != null) {
            user.setNom(userDetails.getNom());
            user.setPrenom(userDetails.getPrenom());
            user.setCIN(userDetails.getCIN());
            user.setTEL(userDetails.getTEL());
            user.setLogin(userDetails.getLogin());
            user.setPassword(userDetails.getPassword());
           // user.setRole(userDetails.getRole());
            return userRepository.save(user);
        } else {
            return null; // Gérer le cas où l'utilisateur n'est pas trouvé
        }
    }

    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }
    
    public User updateUser(User user) {
        if (userRepository.existsById(user.getUserId())) {
            return userRepository.save(user);
        }
        return null;
    }
    public long getNombreUtilisateurs() {
        return userRepository.count();
    }
    
  
    public void resetPassword(User user, String newPassword) {
        user.setPassword(newPassword);
        userRepository.save(user);
    }
    
    
    public List<User> getUsersByRole(RoleType role) {
        return userRepository.findByRole(role);
    }
    public User findByLogin(String login) {
        // Implémentez la logique pour rechercher un utilisateur par login dans la base de données
        return userRepository.findByLogin(login);
    }




}
