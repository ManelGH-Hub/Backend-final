package com.PFE.GStagiaire.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.PFE.GStagiaire.Entity.Suivi;

import com.PFE.GStagiaire.Service.SuiviService;

import java.util.List;

@RestController
@RequestMapping("/api/suivi")
public class SuiviController {

    @Autowired
    private SuiviService suiviService;

    @GetMapping
    public List<Suivi> getAllSuivi() {
        return suiviService.getAllSuivi();
    }

    @GetMapping("/{suiviId}")
    public Suivi getSuiviById(@PathVariable Long suiviId) {
        return suiviService.getSuiviById(suiviId);
    }

    @PostMapping
    public Suivi createSuivi(@RequestBody Suivi suivi) {
        return suiviService.createSuivi(suivi);
    }

    @PutMapping("/{suiviId}")
    public Suivi updateSuivi(@PathVariable Long suiviId, @RequestBody Suivi suiviDetails) {
        return suiviService.updateSuivi(suiviId, suiviDetails);
    }

    @DeleteMapping("/{suiviId}")
    public void deleteSuivi(@PathVariable Long suiviId) {
        suiviService.deleteSuivi(suiviId);
    }
    @GetMapping("/suivi/byUserId/{userId}")
    public ResponseEntity<List<Suivi>> getSuiviByUserId(@PathVariable Long userId) {
        List<Suivi> suivis = suiviService.getSuiviByUserId(userId);
        return ResponseEntity.ok(suivis);
    }
    @PostMapping("/byUserId/{userId}")
    public ResponseEntity<Suivi> createSuiviByUserId(@PathVariable Long userId, @RequestBody Suivi suivi) {
        try {
            Suivi createdSuivi = suiviService.createSuiviByUserId(userId, suivi);
            return ResponseEntity.ok(createdSuivi);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

}
